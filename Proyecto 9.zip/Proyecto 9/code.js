var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["e2800c6c-a72c-458f-8b7d-97646fbe28f1","2a3dbcc8-0c1c-4ad1-af62-61b3e24409c5","32a37f72-fa49-40cf-ace4-ba2131384dcd","7e6c6201-5062-4f91-91d4-e85fe2b70d88","5470f933-7420-41ea-ac8f-96fd3dd2b8e4"],"propsByKey":{"e2800c6c-a72c-458f-8b7d-97646fbe28f1":{"name":"f","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"gM5pvmqojKVbHkBNO48YDKEGkA6gLFYO","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/e2800c6c-a72c-458f-8b7d-97646fbe28f1.png"},"2a3dbcc8-0c1c-4ad1-af62-61b3e24409c5":{"name":"hero1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"tsqleCr.8VPbrp52J2YAjX6.zivWr7iA","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/2a3dbcc8-0c1c-4ad1-af62-61b3e24409c5.png"},"32a37f72-fa49-40cf-ace4-ba2131384dcd":{"name":"enemy_pink_1","sourceUrl":null,"frameSize":{"x":1024,"y":576},"frameCount":2,"looping":true,"frameDelay":12,"version":"KA_IJ3Up_gr.ruYjhALqxNBEQ5iJqy_q","loadedFromSource":true,"saved":true,"sourceSize":{"x":1024,"y":1152},"rootRelativePath":"assets/32a37f72-fa49-40cf-ace4-ba2131384dcd.png"},"7e6c6201-5062-4f91-91d4-e85fe2b70d88":{"name":"enemy_pink_2","sourceUrl":null,"frameSize":{"x":299,"y":287},"frameCount":2,"looping":true,"frameDelay":12,"version":"ZUVw4p0taEdnmeyWZNlcomEhEOcNbGBY","loadedFromSource":true,"saved":true,"sourceSize":{"x":299,"y":574},"rootRelativePath":"assets/7e6c6201-5062-4f91-91d4-e85fe2b70d88.png"},"5470f933-7420-41ea-ac8f-96fd3dd2b8e4":{"name":"enemy_pink_3","sourceUrl":null,"frameSize":{"x":270,"y":265},"frameCount":2,"looping":true,"frameDelay":12,"version":"qxxptNl9S6Yd.u6xNw2igMUuZxDZlono","loadedFromSource":true,"saved":true,"sourceSize":{"x":270,"y":530},"rootRelativePath":"assets/5470f933-7420-41ea-ac8f-96fd3dd2b8e4.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var hero = createSprite(200,345,200,345);
hero.shapeColor="red";

var enemy1 = createSprite(200,250,10,10);
enemy1.shapeColor="red";

var enemy2 = createSprite(200,150,10,10);
enemy2.shapeColor="red";

var enemy3 = createSprite(200,50,10,10);
enemy3.shapeColor="red";

var net = createSprite(200,5,200,20);
net.shapeColor="red";

var goal =0;
var death = 0;

hero.setAnimation("hero1");
hero.scale=.2;
enemy1.setAnimation("enemy_pink_1");
enemy1.scale=.1;
enemy2.setAnimation("enemy_pink_2");
enemy2.scale=.3;
enemy3.setAnimation("enemy_pink_3");
enemy3.scale=.3;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);

function draw() {
  background("black");
  createEdgeSprites();
  enemy1.bounceOff(edges);
  enemy2.bounceOff(edges);
  enemy3.bounceOff(edges);
  if(keyDown(UP_ARROW)){
  hero.y=hero.y-3;
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3;
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3;
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3;
}
if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_alerts/vibrant_game_correct_answer_hit.mp3");
  hero.x=200;
  hero.y=350;
  death = death+1;
}
if(hero.isTouching(net)){
  playSound("assets/category_points/vibrant_game_gold_crystal_bling_touch_1.mp3");
  hero.x=200;
  hero.y=345;
  goal=goal+1;
}
textSize(20);
  fill("white");
  text("Goals:"+goal,320,350);
  

textSize(20);
  fill("white");
  text("death:"+death,20,350);
  drawSprites();
}




// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
